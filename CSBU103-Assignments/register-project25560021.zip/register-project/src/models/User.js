// src/models/User.js (ĐÃ SỬA LỖI LOGIC ĐỒNG BỘ)

// FIX: Lấy hàm getDb thay vì biến db tĩnh
const { getDb } = require('./db'); 

// Hàm giúp lấy collection sau khi đảm bảo DB đã kết nối
const getUserCollection = () => {
    // LẤY ĐỐI TƯỢNG DB BẰNG CÁCH GỌI HÀM GETTER
    const db = getDb();
    
    // Tên collection là 'users'
    return db.collection('users');
};

// Regex và Logic Validation (giữ nguyên)
const PASSWORD_REGEX = /^(?=.*[0-9])(?=.*[!@#$%^&*])(?=.{6,})/;


// ----------------------------------------------------
// LOGIC VALIDATION
// ----------------------------------------------------
exports.validateRegistration = (username, password, reconfirmPassword) => {
    if (!username || !password || !reconfirmPassword) {
        return 'Vui lòng điền đầy đủ tất cả các trường.';
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(username)) {
        return 'Địa chỉ Email không hợp lệ.';
    }
    if (!PASSWORD_REGEX.test(password)) {
        return 'Mật khẩu tối thiểu 6 ký tự, phải chứa ít nhất 1 số và 1 ký tự đặc biệt (!@#$%^&*).';
    }
    if (password !== reconfirmPassword) {
        return 'Mật khẩu xác nhận không khớp.';
    }
    return null; 
};

// ----------------------------------------------------
// LOGIC THAO TÁC VỚI DATABASE
// ----------------------------------------------------

exports.findByUsername = async (username) => {
    const user_db = getUserCollection();
    return await user_db.findOne({ username });
};

exports.create = async (userData) => {
    const user_db = getUserCollection();
    const result = await user_db.insertOne(userData);
    
    return { 
        _id: result.insertedId,
        username: userData.username 
    };
};