// src/models/db.js (PHIÊN BẢN SỬA LỖI HOÀN CHỈNH)

const { MongoClient, ServerApiVersion } = require('mongodb'); 

// FIX 1: XÓA HOÀN TOÀN CÁC KÝ TỰ PLACEHOLDER < > VÀ KÝ TỰ @ THỪA
// CÚ PHÁP ĐÚNG PHẢI LÀ: mongodb+srv://USER:PASSWORD@HOST/DATABASE?OPTIONS
// Vui lòng thay '123456789' bằng MẬT KHẨU THỰC TẾ của tài khoản florid3407_db_user

const uri = "mongodb+srv://florid3407_db_user:123456789%40@csbu103.q5b5rkm.mongodb.net/?appName=CSBU103";

// ********* LƯU Ý MẬT KHẨU CÓ KÝ TỰ ĐẶC BIỆT *********
// Nếu mật khẩu của bạn có ký tự đặc biệt (ví dụ: "123456789@"), bạn phải URL Encode:
// Thay thế @ bằng %40 (ví dụ: '123456789%40')
// const uri = "mongodb+srv://florid3407_db_user:123456789%40@csbu103.q5b5rkm.mongodb.net/?appName=CSBU103";


const client = new MongoClient(uri, {
  serverApi: {
    version: ServerApiVersion.v1,
    strict: true,
    deprecationErrors: true,
  }
});

const dbName = 'webdev_registration'; 
let dbInstance = null; 

async function connectDB() {
    try {
        await client.connect();
        await client.db("admin").command({ ping: 1 });
        
        dbInstance = client.db(dbName);
        console.log("Kết nối MongoDB Atlas thành công!");
        
        return dbInstance;
        
    } catch (error) {
        console.error("LỖI KẾT NỐI MONGODB ATLAS:", error.message);
        throw new Error("Lỗi kết nối DB: Vui lòng kiểm tra kỹ URI (USERNAME/PASSWORD) và Network Access trên Atlas.");
    }
}

function getDb() {
    if (!dbInstance) {
        // Lỗi này chỉ xảy ra nếu code cố gắng dùng DB trước khi connectDB() hoàn tất
        throw new Error("Lỗi kết nối DB: Database chưa được khởi tạo. Vui lòng kiểm tra quá trình khởi động server.");
    }
    return dbInstance;
}

// FIX 2: SỬ DỤNG CÚ PHÁP COMMONJS (exports) PHÙ HỢP VỚI require()
exports.connectDB = connectDB; 
exports.getDb = getDb;