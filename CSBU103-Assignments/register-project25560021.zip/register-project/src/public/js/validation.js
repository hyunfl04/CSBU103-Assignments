// src/public/js/validation.js

$(document).ready(function() {
    
    // Thêm phương thức kiểm tra mật khẩu tùy chỉnh
    $.validator.addMethod("strongPassword", function(value, element) {
        return this.optional(element) || 
               value.length >= 6 && 
               /\d/.test(value) &&           // Phải chứa ít nhất 1 số
               /[!@#$%^&*]/.test(value);    // Phải chứa ít nhất 1 ký tự đặc biệt
    }, "Mật khẩu tối thiểu 6 ký tự, phải có số và ký tự đặc biệt.");

    $("#registerForm").validate({
        rules: {
            username: {
                required: true,
                email: true
            },
            password: {
                required: true,
                strongPassword: true
            },
            reconfirmPassword: {
                required: true,
                equalTo: "#password" // Phải khớp với trường có ID là 'password'
            }
        },
        messages: {
            username: {
                required: "Vui lòng nhập Email.",
                email: "Email không đúng định dạng."
            },
            password: {
                required: "Vui lòng nhập mật khẩu."
            },
            reconfirmPassword: {
                required: "Vui lòng xác nhận mật khẩu.",
                equalTo: "Mật khẩu xác nhận không khớp."
            }
        },
        errorElement: 'div',
        errorPlacement: function(error, element) {
            error.addClass('invalid-feedback');
            error.insertAfter(element);
        },
        highlight: function(element, errorClass, validClass) {
            $(element).addClass('is-invalid').removeClass('is-valid');
        },
        unhighlight: function(element, errorClass, validClass) {
            $(element).removeClass('is-invalid').addClass('is-valid');
        }
    });
});
    function validatePasswordsMatch(passField, confirmField, feedbackId) {
        const passValue = passField.val();
        const confirmValue = confirmField.val();
        
        // Chỉ kiểm tra khi cả hai trường đều có giá trị
        if (!confirmValue) {
            confirmField.removeClass('is-valid').addClass('is-invalid');
            $(feedbackId).text('Vui lòng xác nhận mật khẩu.');
            return false;
        } else if (passValue !== confirmValue) {
            confirmField.removeClass('is-valid').addClass('is-invalid');
            $(feedbackId).text('Mật khẩu xác nhận không khớp.');
            return false;
        } else {
            confirmField.removeClass('is-invalid').addClass('is-valid');
            return true;
        }
    }

    // Live validation (kiểm tra khi người dùng nhập)
    $('#username').on('input', function() {
        validateField($('#username'), emailRegex, '#usernameFeedback', 'Vui lòng nhập định dạng Email hợp lệ.');
    });

    $('#password').on('input', function() {
        validateField($('#password'), passwordRegex, '#passwordFeedback', 'Mật khẩu tối thiểu 6 ký tự, phải chứa ít nhất 1 số và 1 ký tự đặc biệt.');
        validatePasswordsMatch($('#password'), $('#reconfirmPassword'), '#reconfirmPasswordFeedback');
    });

    $('#reconfirmPassword').on('input', function() {
        // Đảm bảo mật khẩu gốc đã pass regex trước khi kiểm tra khớp
        const isPasswordValid = validateField($('#password'), passwordRegex, '#passwordFeedback', 'Mật khẩu tối thiểu 6 ký tự, phải chứa ít nhất 1 số và 1 ký tự đặc biệt.');
        if (isPasswordValid) {
             validatePasswordsMatch($('#password'), $('#reconfirmPassword'), '#reconfirmPasswordFeedback');
        }
    });

    // Form submission validation
    $('#registrationForm').on('submit', function(e) {
        let isValid = true;

        // Validate all fields on submit
        isValid = validateField($('#username'), emailRegex, '#usernameFeedback', 'Vui lòng nhập định dạng Email hợp lệ.') && isValid;
        isValid = validateField($('#password'), passwordRegex, '#passwordFeedback', 'Mật khẩu tối thiểu 6 ký tự, phải chứa ít nhất 1 số và 1 ký tự đặc biệt.') && isValid;
        isValid = validatePasswordsMatch($('#password'), $('#reconfirmPassword'), '#reconfirmPasswordFeedback') && isValid;
        
        // Ngăn form submit nếu có lỗi
        if (!isValid) {
            e.preventDefault();
            e.stopPropagation();
            alert('Vui lòng sửa các lỗi trong biểu mẫu.');
        }
        
        // Nếu tất cả pass, form sẽ submit lên backend
    });