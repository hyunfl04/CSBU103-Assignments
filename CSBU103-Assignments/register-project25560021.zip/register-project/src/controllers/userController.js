// src/controllers/UserController.js

// *******************************************************************
// Sử dụng Alias (@root) để import các hàm từ User.js
// *******************************************************************
const { findByUsername, create, validateRegistration } = require('@root/models/User'); 
const bcrypt = require('bcryptjs'); 

exports.getRegister = (req, res) => {
    res.render('register', { 
        error: null, 
        success: false, 
        title: 'Đăng Ký Tài Khoản'
    });
};

exports.postRegister = async (req, res) => {
    const { username, password, reconfirmPassword } = req.body;

    // 1. Kiểm tra validation phía Back-end
    const validationError = validateRegistration(username, password, reconfirmPassword);
    if (validationError) {
        return res.render('register', { 
            error: validationError, 
            success: false,
            title: 'Đăng Ký Tài Khoản' 
        });
    }

    try {
        // 2. Kiểm tra người dùng đã tồn tại
        if (await findByUsername(username)) {
            return res.render('register', { 
                error: 'Tên đăng nhập (Email) đã được sử dụng.', 
                success: false,
                title: 'Đăng Ký Tài Khoản' 
            });
        }
        
        // 3. Băm mật khẩu (SECURE password storage)
        const hashedPassword = await bcrypt.hash(password, 10); // 10 là saltRounds 

        // 4. Tạo người dùng mới
        const newUser = await create({
            username,
            password: hashedPassword 
        });

        // 5. Thành công: Hiển thị thông báo
        console.log(`Người dùng mới đã đăng ký thành công: ${newUser.username}`);
        return res.render('register', { 
            error: 'Đăng ký thành công! Bạn có thể đăng nhập.',
            success: true, 
            title: 'Đăng Ký Thành Công' 
        });

    } catch (error) {
        console.error('LỖI ĐĂNG KÝ:', error.message);
        
        let errorMessage = 'Đã xảy ra lỗi hệ thống khi đăng ký.';
        
        // Bắt lỗi kết nối DB
        if (error.message.includes('Lỗi kết nối DB')) {
             errorMessage = error.message;
        }
        
        return res.render('register', { 
            error: errorMessage,
            success: false,
            title: 'Lỗi Hệ Thống' 
        });
    }
};