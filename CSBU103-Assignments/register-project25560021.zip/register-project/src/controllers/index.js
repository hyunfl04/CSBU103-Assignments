// src/models/index.js

// Tải (import) module User từ tệp User.js
// require('./User') sẽ trả về tất cả các hàm đã export trong User.js (như findByUsername, create, validateRegistration)
const User = require('./User'); 

// Export đối tượng { User } để các file khác có thể dùng cú pháp destructuring:
// const { User } = require('../models');
module.exports = {
    User: User
};