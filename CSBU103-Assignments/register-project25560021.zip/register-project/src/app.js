// src/app.js (ĐÃ SỬA VÀ HOÀN CHỈNH)

const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const userController = require('./controllers/userController');

// FIX 1: Import hàm connectDB từ db.js. 
// Sử dụng đường dẫn chữ thường `./models/db` để tránh lỗi phân biệt chữ hoa/thường.
const { connectDB } = require('./models/db'); 

const app = express();
// Đặt Port. Thường là 3000 hoặc 5173 như trong ví dụ của bạn.
const port = process.env.PORT || 5173; 

// ------------------------------------------------------------------
// MIDDLEWARE & VIEW ENGINE CONFIGURATION
// ------------------------------------------------------------------

// Cấu hình View Engine là EJS
app.set('view engine', 'ejs');
// Thiết lập thư mục chứa các tệp view (EJS)
app.set('views', path.join(__dirname, 'views'));

// Sử dụng body-parser để xử lý dữ liệu từ form HTML (POST requests)
app.use(bodyParser.urlencoded({ extended: true }));
// Sử dụng express.json để xử lý dữ liệu JSON (nếu có API)
app.use(express.json());

// Phục vụ các tệp tĩnh (CSS, JS, images) từ thư mục 'public'
app.use('/static', express.static(path.join(__dirname, 'public')));

// Phục vụ các package từ node_modules ra client side (Dùng cho Bootstrap, jQuery,...)
// Điều này rất quan trọng nếu các tệp EJS của bạn dùng /node_modules/...
app.use('/node_modules', express.static(path.join(__dirname, '..', 'node_modules')));

// ------------------------------------------------------------------
// ROUTING
// ------------------------------------------------------------------

// Chuyển hướng '/' sang trang đăng ký (theo logic của dự án đăng ký)
app.get('/', (req, res) => res.redirect('/register')); 

// Route GET: Hiển thị trang đăng ký
app.get('/register', userController.getRegister);

// Route POST: Xử lý dữ liệu form đăng ký
app.post('/register', userController.postRegister);

// ------------------------------------------------------------------
// KHỞI ĐỘNG SERVER (Đảm bảo kết nối DB trước)
// ------------------------------------------------------------------

async function startServer() {
    try {
        // 1. Chờ kết nối DB hoàn tất. 
        // Lệnh này giờ sẽ chạy thành công vì hàm connectDB đã được export đúng.
        await connectDB();
        
        // 2. Khởi động Server Express
        app.listen(port, () => {
            console.log(`Server Express chạy tại http://localhost:${port}`);
            console.log(`Mở trang Đăng ký: http://localhost:${port}/register`);
        });
    } catch (error) {
        // Xử lý lỗi nếu connectDB thất bại (do chuỗi kết nối sai hoặc Network Access bị chặn)
        console.error("KHỞI ĐỘNG THẤT BẠI:", error.message);
        // Dừng ứng dụng nếu không thể kết nối DB
        process.exit(1); 
    }
}

// Bắt đầu quá trình khởi động
startServer();